const { cartData, categoriesData, deliveryAddressData, orderItemsData, orderData, productsData, storesData, userData, wishlistData } = require('./data/db_client');

exports.handler = async (event) => {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',  // Allow all origins, or specify a domain
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    try {
        const body = event ? event : null;
        
        if(!body || body === null){
            return {
                statusCode: 500,
                body: JSON.stringify({ error: 'Empty body. Please check payload' }),
            };
        }

        const { path } = body;

        if(path === '/add/cart') {
            try {
                const { mobile, product_id, quantity } = req.body;
                const result = await cartData.addToCart(mobile, product_id, quantity);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/get/cart') {
            try {
                const { mobile } = req.body;
                const result = await cartData.getCart(mobile);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/update/cart') {
            try {
                const { mobile, product_id, quantity } = req.body;
                const result = await cartData.updateCart(mobile, product_id, quantity);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/remove/cart') {
            try {
                const { mobile, product_id } = req.body;
                const result = await cartData.removeFromCart(mobile, product_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/create/category') {
            try {
                const category = req.body;
                const result = await categoriesData.createCategory(category);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/categories') {
            try {
                const result = await categoriesData.getCategories();
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/update/category') {
            try {
                const category = req.body;
                const result = await categoriesData.updateCategory(category);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/delete/category') {
            try {
                const { id } = req.body;
                const result = await categoriesData.deleteCategory(id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/add/deliveryAddress') {
            try {
                const deliveryAddress = req.body;
                const result = await deliveryAddressData.createDeliveryAddress(deliveryAddress);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/deliveryAddress') {
            try {
                const { user_id } = req.body;
                const result = await deliveryAddressData.getDeliveryAddresses(user_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/update/deliveryAddress') {
            try {
                const deliveryAddress = req.body;
                const result = await deliveryAddressData.updateDeliveryAddress(deliveryAddress);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/remove/deliveryAddress') {
            try {
                const { id } = req.body;
                const result = await deliveryAddressData.deleteDeliveryAddress(id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/add/orderItem') {
            try {
                const orderItems = req.body;
                const result = await orderItemsData.createOrderItem(orderItems);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/orderItem') {
            try {
                const { order_id } = req.body;
                const result = await orderItemsData.getOrderItems(order_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/update/orderItem') {
            try {
                const orderItems = req.body;
                const result = await orderItemsData.updateOrderItem(orderItems);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/remove/orderItem') {
            try {
                const { order_id } = req.body;
                const result = await orderItemsData.deleteOrderItem(order_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/add/order') {
            try {
                const orders = req.body;
                const result = await orderData.createOrder(orders);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/order') {
            try {
                const { user_id } = req.body;
                const result = await orderData.updateOrder(user_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/update/order') {
            try {
                const orders = req.body;
                const result = await orderData.updateOrder(orders);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/remove/order') {
            try {
                const { order_id } = req.body;
                const result = await orderData.deleteOrder(order_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if( path === '/create/product') {
            try {
                const product = req.body;
                const result = await productsData.createProduct(product);
                if(result) {
                    res.status(201).send({
                        success: true,
                    });
                } else {
                    res.status(200).send({
                        success: false,
                    });
                }
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/accept/product') {
            try {
                const { id } = req.body;
                const result = await productsData.acceptProduct(id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/reject/product') {
            try {
                const { id, comments } = req.body;
                const result = await productsData.rejectProduct(id, comments);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/products') {
            try {
                const { category } = req.body;
                const result = await productsData.getAllProducts(category);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/update/product') {
            try {
                const product = req.body;
                const result = await productsData.updateProduct(product);
                if(result) {
                    res.status(201).send({
                        success: true,
                    });
                } else {
                    res.status(200).send({
                        success: false,
                    });
                }
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/product') {
            try {
                const { id } = req.body;
                const result = await productsData.getProduct(id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/delete/product') {
            try {
                const { id } = req.body;
                const result = await productsData.deleteProduct(id);
                if(result) {
                    res.status(201).send({
                        success: true,
                    });
                } else {
                    res.status(200).send({
                        success: false,
                    });
                }
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/products/for/seller') {
            try {
                const { mobile } = req.body;
                const result = await productsData.getProductsForSeller(mobile);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/create/store') {
            try {
                const store = req.body;
                const result = await storesData.createStore(store);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/stores') {
            try {
                const result = await storesData.getStores();
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/update/store') {
            try {
                const store = req.body;
                const result = await storesData.updateStore(store);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/delete/store') {
            try {
                const { id } = req.body;
                const result = await storesData.deleteStore(id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/accept/seller') {
            try {
                const { mobile } = req.body;
                const result = await storesData.acceptSeller(mobile);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/reject/seller') {
            try {
                const { mobile, comments } = req.body;
                const result = await storesData.rejectSeller(mobile, comments);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/user/onboarding') {
            try {
                const user = req.body;
                const result = await userData.registerUser(user);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/login/user') {
            try {                
                const { emailOrMob, password } = req.body;
                const user = await userData.getUserByEmailOrMob(emailOrMob);
                
                if (user.password === password) {
                    res.status(200).send(user);
                } else {
                    res.status(401).send('Invalid password');
                }
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/send/otp') {
            try {
                const { mobile } = req.body;
                // await userData.sendOTP(mobile);
                res.status(200).send('OTP sent successfully');
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/verify/otp') {
            try {
                const { mobile, otp } = req.body;
                const result = await userData.verifyOTP(mobile, otp);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/deregister/user') {
            try {
                const { email } = req.body;
                const result = await userData.deRegisterUser(email);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/user') {
            try {
                const { mobile } = req.body;
                const result = await userData.getUserByEmailOrMob(mobile);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/register/seller') {
            try {
                const seller = req.body;
                const result = await userData.registerSeller(seller);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/get/user-type') {
            try {
                const { mobile } = req.body;
                const result = await userData.getUserType(mobile);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/get/submitted-sellers') {
            try {
                const result = await userData.getSubmittedSellers();
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/get/seller-submitted-details') {
            try {
                const { mobile } = req.body;
                const result = await userData.getSellerSubmittedDetails(mobile);
                res.status(200).send(result);
            } catch (error) {
                console.log("Error: ", error);
                res.status(500).send(error);
            }
        } else if(path === '/create/wishlist') {
            try {
                const { mobile, product_id } = req.body;
                const result = await wishlistData.addToWishlist(mobile, product_id);
                res.status(201).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/get/wishlist') {
            try {
                const { mobile } = req.body;
                const result = await wishlistData.getWishlist(mobile);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else if(path === '/delete/wishlist') {
            try {
                const { mobile, product_id } = req.body;
                const result = await wishlistData.removeFromWishlist(mobile, product_id);
                res.status(200).send(result);
            } catch (error) {
                res.status(500).send(error);
            }
        } else {
            return {
                statusCode: 500,
                body: JSON.stringify({ error: 'Invalid path. Please check payload' }),
            };
        }
    } catch (error) {
        console.error('Database query failed', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Database query failed' }),
        };
    }
}